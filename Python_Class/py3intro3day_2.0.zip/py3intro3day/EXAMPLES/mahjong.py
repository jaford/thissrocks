#!/usr/bin/env python

for i in range(0x1F000, 0x1F02B):
    print(chr(i), end=' ')
print()

